
import pandas as pd
import numpy as np
from sklearn.naive_bayes import GaussianNB
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix,
)

# Intentamos usar XGBoost (libreria real, pedida por el enunciado).
# Si no esta instalada, usamos HistGradientBoostingClassifier de
# sklearn como respaldo, para que el script nunca se caiga.
try:
    from xgboost import XGBClassifier
    LIBRERIA_BOOSTING = "XGBoost"
except ImportError:
    from sklearn.ensemble import HistGradientBoostingClassifier
    LIBRERIA_BOOSTING = "HistGradientBoosting (respaldo, XGBoost no instalado)"

# ---------------------------------------------------------------
# 1. Carga del dataset limpio
# ---------------------------------------------------------------
RUTA_CSV = "outputs/dataset_limpio.csv"
df = pd.read_csv(RUTA_CSV)

variables_binarias = ["Is declined", "isForeignTransaction", "isHighRiskCountry"]
for col in variables_binarias:
    if not pd.api.types.is_numeric_dtype(df[col]):
        df[col] = df[col].map({"Y": 1, "N": 0})

variables_predictoras = [
    "Average Amount/transaction/day",
    "Transaction_amount",
    "Is declined",
    "Total Number of declines/day",
    "isForeignTransaction",
    "isHighRiskCountry",
    "Daily_chargeback_avg_amt",
    "6_month_avg_chbk_amt",
    "6-month_chbk_freq",
]

X = df[variables_predictoras].to_numpy(dtype=float)
y = (df["isFradulent"] == "Y").to_numpy(dtype=int)

# MISMA particion para los 4 modelos
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42, stratify=y
)

print(f"Particion: {len(X_train)} entrenamiento / {len(X_test)} prueba "
      f"({y_test.sum()} fraudes reales en prueba)\n")

# Version estandarizada (solo la necesita SVM)
media_train = X_train.mean(axis=0)
desviacion_train = X_train.std(axis=0) + 1e-9
X_train_std = (X_train - media_train) / desviacion_train
X_test_std = (X_test - media_train) / desviacion_train


# ---------------------------------------------------------------
# 2. Entrenar los 4 modelos con la misma particion
# ---------------------------------------------------------------
modelos_entrenados = {}

# a) Naive Bayes
modelo_nb = GaussianNB()
modelo_nb.fit(X_train, y_train)
modelos_entrenados["Naive Bayes"] = (
    modelo_nb.predict(X_test),
    modelo_nb.predict_proba(X_test)[:, 1],
)

# b) Random Forest
modelo_rf = RandomForestClassifier(n_estimators=100, max_depth=6, random_state=42)
modelo_rf.fit(X_train, y_train)
modelos_entrenados["Random Forest"] = (
    modelo_rf.predict(X_test),
    modelo_rf.predict_proba(X_test)[:, 1],
)

# c) Boosting (XGBoost si esta disponible)
scale_pos_weight = (y_train == 0).sum() / (y_train == 1).sum()
if LIBRERIA_BOOSTING == "XGBoost":
    modelo_boost = XGBClassifier(
        n_estimators=200, learning_rate=0.1, max_depth=4,
        scale_pos_weight=scale_pos_weight, eval_metric="logloss", random_state=42,
    )
    modelo_boost.fit(X_train, y_train)
else:
    pesos_muestra = np.where(y_train == 1, scale_pos_weight, 1.0)
    modelo_boost = HistGradientBoostingClassifier(
        max_iter=200, learning_rate=0.1, max_depth=4, random_state=42,
    )
    modelo_boost.fit(X_train, y_train, sample_weight=pesos_muestra)

modelos_entrenados[f"Boosting ({LIBRERIA_BOOSTING})"] = (
    modelo_boost.predict(X_test),
    modelo_boost.predict_proba(X_test)[:, 1],
)

# d) SVM (kernel RBF, mejores hiperparametros ya encontrados: C=1, gamma=1)
modelo_svm = SVC(kernel="rbf", C=1, gamma=1, probability=True, random_state=42)
modelo_svm.fit(X_train_std, y_train)
modelos_entrenados["SVM (RBF, C=1, gamma=1)"] = (
    modelo_svm.predict(X_test_std),
    modelo_svm.predict_proba(X_test_std)[:, 1],
)


# ---------------------------------------------------------------
# 3. Tabla comparativa final
# ---------------------------------------------------------------
print("=" * 70)
print("TABLA COMPARATIVA FINAL - 4 modelos, misma particion train/test")
print("=" * 70)

resultados = []
for nombre, (pred, prob) in modelos_entrenados.items():
    vp = np.sum((pred == 1) & (y_test == 1))
    fn = np.sum((pred == 0) & (y_test == 1))
    fp = np.sum((pred == 1) & (y_test == 0))

    resultados.append(
        {
            "modelo": nombre,
            "accuracy": accuracy_score(y_test, pred),
            "precision": precision_score(y_test, pred),
            "recall": recall_score(y_test, pred),
            "f1": f1_score(y_test, pred),
            "auc": roc_auc_score(y_test, prob),
            "falsos_negativos": fn,
            "falsos_positivos": fp,
            "verdaderos_positivos": vp,
        }
    )

tabla_final = pd.DataFrame(resultados).sort_values("recall", ascending=False)
print(tabla_final.round(4).to_string(index=False))
print()

mejor_modelo = tabla_final.iloc[0]
peor_modelo = tabla_final.iloc[-1]
total_fraudes_test = int(y_test.sum())

print(
    f"De los {total_fraudes_test} fraudes reales en el conjunto de prueba:\n"
    f"  - El mejor modelo ({mejor_modelo['modelo']}) dejo pasar "
    f"{int(mejor_modelo['falsos_negativos'])} sin detectar.\n"
    f"  - El de peor recall ({peor_modelo['modelo']}) dejo pasar "
    f"{int(peor_modelo['falsos_negativos'])} sin detectar."
)
print()

# ---------------------------------------------------------------
# 4. Guardar resultados para el informe
# ---------------------------------------------------------------
tabla_final.round(4).to_csv("outputs/tabla_comparativa_final.csv", index=False)
print("Tabla guardada en: outputs/tabla_comparativa_final.csv")