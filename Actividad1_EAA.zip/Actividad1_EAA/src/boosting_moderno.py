

import pandas as pd
import numpy as np
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
)
from xgboost import XGBClassifier

# ---------------------------------------------------------------
# 1. Carga del dataset limpio
# ---------------------------------------------------------------
RUTA_CSV = "outputs/dataset_limpio.csv"
df = pd.read_csv(RUTA_CSV)

variables_binarias = ["Is declined", "isForeignTransaction", "isHighRiskCountry"]
for col in variables_binarias:
    if not pd.api.types.is_numeric_dtype(df[col]):
        df[col] = df[col].map({"Y": 1, "N": 0})

variables_predictoras = [
    "Average Amount/transaction/day",
    "Transaction_amount",
    "Is declined",
    "Total Number of declines/day",
    "isForeignTransaction",
    "isHighRiskCountry",
    "Daily_chargeback_avg_amt",
    "6_month_avg_chbk_amt",
    "6-month_chbk_freq",
]

X = df[variables_predictoras].to_numpy(dtype=float)
y = (df["isFradulent"] == "Y").to_numpy(dtype=int)

# MISMA particion train/test para los 4 modelos (requisito explicito
# del enunciado: comparar bajo las mismas condiciones)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42, stratify=y
)


# =================================================================
# PARTE A - ADABOOST IMPLEMENTADO A MANO
# =================================================================
# Algoritmo (SAMME, la version de AdaBoost para clasificacion con
# etiquetas -1/+1):
#   1) Inicializar pesos iguales para todas las muestras: w_i = 1/n
#   2) Para cada uno de M modelos debiles (M rondas de boosting):
#      a) Entrenar un arbol MUY simple (un "stump", profundidad 1)
#         usando los pesos actuales w_i
#      b) Calcular su error ponderado: err = suma(w_i para los que
#         fallo) / suma(todos los w_i)
#      c) Calcular su "voto" alpha = 0.5 * ln((1-err)/err)
#         (entre mas bajo el error, mas peso tiene su voto)
#      d) Actualizar los pesos: aumentar el peso de los casos que
#         este modelo fallo, disminuir el de los que acerto
#      e) Normalizar los pesos para que sumen 1
#   3) Prediccion final = signo de la suma ponderada de todos los
#      votos: sum(alpha_m * prediccion_m(x))
# =================================================================
def adaboost_manual_fit(X, y, n_modelos=100, semilla=42):
    n = len(y)
    y_signo = np.where(y == 1, 1, -1)  # convertir a {-1, +1}

    pesos = np.full(n, 1 / n)
    modelos = []
    alphas = []

    for m in range(n_modelos):
        # a) Modelo debil: un "stump" (arbol de profundidad 1)
        stump = DecisionTreeClassifier(max_depth=1, random_state=semilla + m)
        stump.fit(X, y_signo, sample_weight=pesos)
        prediccion = stump.predict(X)

        # b) Error ponderado
        fallos = (prediccion != y_signo).astype(float)
        error_ponderado = np.sum(pesos * fallos) / np.sum(pesos)
        error_ponderado = np.clip(error_ponderado, 1e-10, 1 - 1e-10)  # evitar log(0)

        # c) Peso del voto de este modelo (alpha)
        alpha = 0.5 * np.log((1 - error_ponderado) / error_ponderado)

        # d) Actualizar pesos: exp(-alpha * y * prediccion)
        #    si acerto (y*pred=1) el peso baja; si fallo (y*pred=-1) el peso sube
        pesos = pesos * np.exp(-alpha * y_signo * prediccion)
        pesos = pesos / np.sum(pesos)  # e) normalizar

        modelos.append(stump)
        alphas.append(alpha)

    return modelos, np.array(alphas)


def adaboost_manual_predict_proba(X, modelos, alphas):
    """Convierte la suma ponderada de votos en una pseudo-probabilidad
    usando la funcion sigmoide (igual que hace SAMME.R internamente)"""
    suma_ponderada = np.zeros(len(X))
    for modelo, alpha in zip(modelos, alphas):
        suma_ponderada += alpha * modelo.predict(X)

    return 1 / (1 + np.exp(-suma_ponderada))


print("=" * 70)
print("ADABOOST IMPLEMENTADO A MANO (100 modelos debiles / stumps)")
print("=" * 70)
modelos_ada, alphas_ada = adaboost_manual_fit(X_train, y_train, n_modelos=100, semilla=42)
prob_ada = adaboost_manual_predict_proba(X_test, modelos_ada, alphas_ada)
y_pred_ada = (prob_ada >= 0.5).astype(int)

print(f"Alpha promedio de los modelos debiles: {alphas_ada.mean():.4f}")
print(f"Alpha del primer modelo (mas generico): {alphas_ada[0]:.4f}")
print(f"Alpha del ultimo modelo (mas especializado en errores dificiles): "
      f"{alphas_ada[-1]:.4f}")
print()
print(f"Accuracy  = {accuracy_score(y_test, y_pred_ada):.4f}")
print(f"Precision = {precision_score(y_test, y_pred_ada):.4f}")
print(f"Recall    = {recall_score(y_test, y_pred_ada):.4f}")
print(f"F1-score  = {f1_score(y_test, y_pred_ada):.4f}")
print(f"AUC       = {roc_auc_score(y_test, prob_ada):.4f}")
print()


# =================================================================
# PARTE B - BOOSTING MODERNO: XGBoost
# =================================================================
print("=" * 70)
print("BOOSTING MODERNO - XGBoost")
print("=" * 70)

# Manejo explicito del desbalance de clases: XGBoost tiene un
# parametro nativo para esto, scale_pos_weight, que se calcula como
# (numero de negativos) / (numero de positivos) -- exactamente la
# misma idea de las clases desbalanceadas que vimos en el Punto 1a.
scale_pos_weight = (y_train == 0).sum() / (y_train == 1).sum()
print(f"scale_pos_weight (peso de la clase minoritaria = fraude): "
      f"{scale_pos_weight:.2f}")
print()

modelo_xgb = XGBClassifier(
    n_estimators=200,       # numero de arboles (rondas de boosting)
    learning_rate=0.1,      # tasa de aprendizaje
    max_depth=4,            # profundidad maxima de cada arbol
    scale_pos_weight=scale_pos_weight,
    eval_metric="logloss",
    random_state=42,
)
modelo_xgb.fit(X_train, y_train)
y_pred_xgb = modelo_xgb.predict(X_test)
prob_xgb = modelo_xgb.predict_proba(X_test)[:, 1]

print(f"Hiperparametros: n_estimators=200, learning_rate=0.1, max_depth=4, "
      f"scale_pos_weight={scale_pos_weight:.2f}")
print(f"Accuracy  = {accuracy_score(y_test, y_pred_xgb):.4f}")
print(f"Precision = {precision_score(y_test, y_pred_xgb):.4f}")
print(f"Recall    = {recall_score(y_test, y_pred_xgb):.4f}")
print(f"F1-score  = {f1_score(y_test, y_pred_xgb):.4f}")
print(f"AUC       = {roc_auc_score(y_test, prob_xgb):.4f}")
print()

# Importancia de variables segun XGBoost (extra, util para conectar
# con el punto de XAI)
importancia_xgb = pd.DataFrame(
    {
        "variable": variables_predictoras,
        "importancia_xgb": modelo_xgb.feature_importances_,
    }
).sort_values("importancia_xgb", ascending=False)

print("Importancia de variables segun XGBoost:")
print(importancia_xgb.round(4).to_string(index=False))
print()


# =================================================================
# PARTE C - COMPARACION FINAL: Naive Bayes, Random Forest, AdaBoost,
# XGBoost -- TODOS con la MISMA particion train/test
# =================================================================
print("=" * 70)
print("TABLA COMPARATIVA - misma particion train/test para los 4 modelos")
print("=" * 70)

# Naive Bayes
modelo_nb = GaussianNB()
modelo_nb.fit(X_train, y_train)
pred_nb = modelo_nb.predict(X_test)
prob_nb = modelo_nb.predict_proba(X_test)[:, 1]

# Random Forest (mismos hiperparametros que en el punto de MLOps)
modelo_rf = RandomForestClassifier(n_estimators=100, max_depth=6, random_state=42)
modelo_rf.fit(X_train, y_train)
pred_rf = modelo_rf.predict(X_test)
prob_rf = modelo_rf.predict_proba(X_test)[:, 1]

resultados = []
for nombre, pred, prob in [
    ("Naive Bayes", pred_nb, prob_nb),
    ("Random Forest", pred_rf, prob_rf),
    ("AdaBoost (manual)", y_pred_ada, prob_ada),
    ("XGBoost", y_pred_xgb, prob_xgb),
]:
    resultados.append(
        {
            "modelo": nombre,
            "accuracy": accuracy_score(y_test, pred),
            "precision": precision_score(y_test, pred),
            "recall": recall_score(y_test, pred),
            "f1": f1_score(y_test, pred),
            "auc": roc_auc_score(y_test, prob),
        }
    )

tabla_comparativa = pd.DataFrame(resultados).sort_values("recall", ascending=False)
print(tabla_comparativa.round(4).to_string(index=False))
print()
print(
    "Ordenado por RECALL (la metrica mas critica en fraude): el modelo "
    "en la primera fila es el que menos fraudes reales deja pasar."
)
print()

# ---------------------------------------------------------------
# Guardar resultados para el informe
# ---------------------------------------------------------------
tabla_comparativa.round(4).to_csv("outputs/boosting_tabla_comparativa.csv", index=False)
importancia_xgb.round(4).to_csv("outputs/boosting_importancia_xgb.csv", index=False)

print("Resultados guardados en la carpeta 'outputs/'")