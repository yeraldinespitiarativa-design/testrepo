

import pandas as pd
import numpy as np

# ---------------------------------------------------------------
# 1. Carga del dataset
# ---------------------------------------------------------------
RUTA_CSV = "data/creditcardcsvpresent.csv"
df = pd.read_csv(RUTA_CSV)

n_filas_total = len(df)

# ---------------------------------------------------------------
# 2. Diagnostico de valores faltantes por columna
#    (formula explicita: porcentaje = nulos / total * 100)
# ---------------------------------------------------------------
nulos_por_columna = df.isnull().sum()
porcentaje_nulos = (nulos_por_columna / n_filas_total) * 100

diagnostico = pd.DataFrame(
    {
        "n_nulos": nulos_por_columna,
        "porcentaje_nulos_%": porcentaje_nulos.round(2),
        "n_validos": n_filas_total - nulos_por_columna,
    }
).sort_values("porcentaje_nulos_%", ascending=False)

print("=" * 70)
print("DIAGNOSTICO DE VALORES FALTANTES POR COLUMNA")
print("=" * 70)
print(diagnostico.to_string())
print()

# ---------------------------------------------------------------
# 3. Regla de decision explicita para el tratamiento
#
#    Umbral pedagogico (justificacion en el informe):
#    - > 60% de nulos  -> ELIMINAR la columna (imputar seria
#      inventar la mayoria de los datos, no recuperarlos)
#    - 0% < nulos <= 60% -> IMPUTAR (media si la variable es
#      numerica con distribucion simetrica, mediana si tiene
#      outliers/sesgo, moda si es categorica)
#    - 0% de nulos -> no requiere tratamiento
# ---------------------------------------------------------------
UMBRAL_ELIMINACION = 60.0  # porcentaje

columnas_a_eliminar = diagnostico[
    diagnostico["porcentaje_nulos_%"] > UMBRAL_ELIMINACION
].index.tolist()

columnas_a_imputar = diagnostico[
    (diagnostico["porcentaje_nulos_%"] > 0)
    & (diagnostico["porcentaje_nulos_%"] <= UMBRAL_ELIMINACION)
].index.tolist()

print("=" * 70)
print("DECISION APLICADA")
print("=" * 70)
print(f"Umbral de eliminacion: > {UMBRAL_ELIMINACION}% de nulos\n")
print(f"Columnas a ELIMINAR ({len(columnas_a_eliminar)}):")
for col in columnas_a_eliminar:
    pct = diagnostico.loc[col, "porcentaje_nulos_%"]
    print(f"  - {col}: {pct}% de nulos")

print(f"\nColumnas a IMPUTAR ({len(columnas_a_imputar)}):")
if columnas_a_imputar:
    for col in columnas_a_imputar:
        pct = diagnostico.loc[col, "porcentaje_nulos_%"]
        print(f"  - {col}: {pct}% de nulos")
else:
    print("  Ninguna.")
print()

# ---------------------------------------------------------------
# 4. Aplicar el tratamiento
# ---------------------------------------------------------------
df_limpio = df.drop(columns=columnas_a_eliminar)

# Por si en el futuro alguna columna cae en el rango de imputacion,
# dejamos la logica lista (aunque en este dataset no se active):
for col in columnas_a_imputar:
    if pd.api.types.is_numeric_dtype(df_limpio[col]):
        sesgo = df_limpio[col].skew()
        if abs(sesgo) > 1:
            valor_relleno = df_limpio[col].median()
            metodo = "mediana (variable sesgada)"
        else:
            valor_relleno = df_limpio[col].mean()
            metodo = "media (variable simetrica)"
    else:
        valor_relleno = df_limpio[col].mode().iloc[0]
        metodo = "moda (variable categorica)"

    df_limpio[col] = df_limpio[col].fillna(valor_relleno)
    print(f"Columna '{col}' imputada con {metodo}: valor = {valor_relleno}")

# ---------------------------------------------------------------
# 5. Verificacion final: ya no deben quedar nulos
# ---------------------------------------------------------------
nulos_restantes = df_limpio.isnull().sum().sum()

print("=" * 70)
print("VERIFICACION FINAL")
print("=" * 70)
print(f"Filas antes del tratamiento: {n_filas_total}")
print(f"Filas despues del tratamiento: {len(df_limpio)}  (no se elimino ninguna fila)")
print(f"Columnas antes: {df.shape[1]}  ->  Columnas despues: {df_limpio.shape[1]}")
print(f"Total de valores nulos restantes en el dataset: {nulos_restantes}")

if nulos_restantes == 0:
    print("-> OK: el dataset quedo completamente libre de valores faltantes.")
else:
    print("-> ATENCION: aun quedan valores nulos, revisar antes de continuar.")

# ---------------------------------------------------------------
# 6. Guardar el dataset limpio para los siguientes puntos (2, 3, Parte 2)
# ---------------------------------------------------------------
RUTA_LIMPIO = "outputs/dataset_limpio.csv"
df_limpio.to_csv(RUTA_LIMPIO, index=False)
diagnostico.to_csv("outputs/diagnostico_missing.csv")

print(f"\nDataset limpio guardado en: {RUTA_LIMPIO}")
print("Este archivo es el que usaremos de aqui en adelante (K-means, "
      "deteccion de anomalias, y toda la Parte 2).")