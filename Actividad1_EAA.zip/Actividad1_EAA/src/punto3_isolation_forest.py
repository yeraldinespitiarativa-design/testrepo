

import pandas as pd
import numpy as np
from sklearn.ensemble import IsolationForest

# ---------------------------------------------------------------
# 1. Carga del dataset limpio
# ---------------------------------------------------------------
RUTA_CSV = "outputs/dataset_limpio.csv"
df = pd.read_csv(RUTA_CSV)

# Codificar variables binarias (igual que en el Punto 2)
variables_binarias = ["Is declined", "isForeignTransaction", "isHighRiskCountry"]
for col in variables_binarias:
    if not pd.api.types.is_numeric_dtype(df[col]):
        df[col] = df[col].map({"Y": 1, "N": 0})

variables_features = [
    "Average Amount/transaction/day",
    "Transaction_amount",
    "Is declined",
    "Total Number of declines/day",
    "isForeignTransaction",
    "isHighRiskCountry",
    "Daily_chargeback_avg_amt",
    "6_month_avg_chbk_amt",
    "6-month_chbk_freq",
]

X = df[variables_features].to_numpy(dtype=float)
y_real = (df["isFradulent"] == "Y").to_numpy(dtype=int)


# ---------------------------------------------------------------
# 2. Como funciona Isolation Forest (referencia conceptual)
#
#    Isolation Forest construye muchos arboles de aislamiento:
#    en cada arbol, se elige una variable al azar y un punto de
#    corte al azar dentro de su rango, dividiendo los datos de
#    forma recursiva hasta aislar cada punto en su propia hoja.
#
#    Un punto anomalo se aisla con POCAS divisiones (porque es
#    distinto a todo lo demas), mientras que un punto normal
#    necesita MUCHAS divisiones (esta rodeado de puntos similares).
#
#    El puntaje de anomalia de un punto x se calcula como:
#
#        s(x, n) = 2 ^ ( -E[h(x)] / c(n) )
#
#    donde:
#      E[h(x)] = longitud de camino promedio de x entre todos los
#                arboles del bosque (cuantas divisiones le tomo
#                aislarlo)
#      c(n)    = longitud de camino promedio esperada para un punto
#                cualquiera en un arbol binario con n muestras,
#                que se calcula como:
#                c(n) = 2*H(n-1) - (2*(n-1)/n)
#                con H(i) el numero armonico ~= ln(i) + 0.5772 (constante
#                de Euler-Mascheroni)
#
#    Interpretacion de s(x, n):
#      s cercano a 1   -> punto MUY probablemente anomalo (se aisla rapido)
#      s cercano a 0.5 -> punto normal (necesita muchas divisiones)
#      s cercano a 0   -> punto claramente normal
# ---------------------------------------------------------------
def c_factor(n):
    """Longitud de camino promedio esperada c(n) para un BST con n muestras"""
    if n <= 1:
        return 0
    numero_armonico = np.log(n - 1) + 0.5772156649  # aproximacion de H(n-1)
    return 2 * numero_armonico - (2 * (n - 1) / n)


n_muestras = len(X)
print("=" * 70)
print("REFERENCIA CONCEPTUAL - factor de normalizacion c(n)")
print("=" * 70)
print(f"Con n = {n_muestras} muestras, c(n) = {c_factor(n_muestras):.4f}")
print(
    "Este valor se usa internamente por el algoritmo para normalizar "
    "la longitud de camino de cada punto y convertirla en un puntaje "
    "entre 0 y 1. No lo calculamos manualmente arbol por arbol (séria "
    "computacionalmente muy costoso reproducirlo a mano con miles de "
    "arboles), pero sklearn.IsolationForest implementa exactamente "
    "esta formula."
)
print()

# ---------------------------------------------------------------
# 3. Experimentacion con distintos porcentajes de contamination
#    (esto es lo que el profesor pidio hacer: "jugar" con el
#    porcentaje y ver cual se acerca mas al fraude real)
# ---------------------------------------------------------------
porcentajes_a_probar = [0.03, 0.04, 0.05, 0.06, 0.07]

print("=" * 70)
print("EXPERIMENTACION CON DISTINTOS % DE CONTAMINATION")
print("=" * 70)

resultados_experimento = []

for contamination in porcentajes_a_probar:
    modelo = IsolationForest(
        contamination=contamination, random_state=42, n_estimators=200
    )
    # fit_predict: devuelve -1 para anomalia, 1 para normal
    prediccion = modelo.fit_predict(X)
    es_anomalia = (prediccion == -1).astype(int)

    n_anomalias = es_anomalia.sum()
    # de los marcados como anomalia, cuantos SI eran fraude real
    verdaderos_entre_anomalias = y_real[es_anomalia == 1].sum()
    porcentaje_acierto = (
        verdaderos_entre_anomalias / n_anomalias * 100 if n_anomalias > 0 else 0
    )
    # de todo el fraude real, cuanto logramos capturar (recall)
    recall_fraude = verdaderos_entre_anomalias / y_real.sum() * 100

    resultados_experimento.append(
        {
            "contamination_%": contamination * 100,
            "n_marcadas_anomalas": n_anomalias,
            "de_esas_son_fraude_real": verdaderos_entre_anomalias,
            "%_acierto_dentro_de_anomalias": round(porcentaje_acierto, 2),
            "%_del_fraude_total_capturado": round(recall_fraude, 2),
        }
    )

tabla_experimento = pd.DataFrame(resultados_experimento)
print(tabla_experimento.to_string(index=False))
print()
print(
    "Lectura de esta tabla: '%_acierto_dentro_de_anomalias' responde "
    "-de lo que marque como anomalo, cuanto era fraude real de "
    "verdad-. '%_del_fraude_total_capturado' responde -de TODO el "
    "fraude que existe, cuanto logre encontrar-. Ambos son necesarios: "
    "un contamination muy bajo puede dar alta precision pero capturar "
    "poco fraude; uno muy alto captura mas fraude pero con mas ruido."
)
print()

# ---------------------------------------------------------------
# 4. Modelo final con el contamination elegido (5%, el valor que
#    usa la literatura como referencia y que el profesor validó
#    como razonable en el foro)
# ---------------------------------------------------------------
CONTAMINATION_ELEGIDO = 0.05

print("=" * 70)
print(f"MODELO FINAL - contamination = {CONTAMINATION_ELEGIDO}")
print("=" * 70)

modelo_final = IsolationForest(
    contamination=CONTAMINATION_ELEGIDO, random_state=42, n_estimators=200
)
prediccion_final = modelo_final.fit_predict(X)
df["es_anomalia"] = (prediccion_final == -1).astype(int)

# El score_samples de sklearn devuelve un valor relacionado con s(x,n):
# valores mas bajos (mas negativos) = mas anomalo
df["score_anomalia"] = modelo_final.score_samples(X)

n_anomalias_final = df["es_anomalia"].sum()
tabla_cruzada = pd.crosstab(
    df["es_anomalia"], df["isFradulent"], margins=True, margins_name="Total"
)
tabla_cruzada.index = ["Normal (predicho)", "Anomalia (predicho)", "Total"]

print(f"Total de transacciones marcadas como anomalas: {n_anomalias_final}")
print(f"Eso representa el {n_anomalias_final / len(df) * 100:.2f}% del dataset\n")
print("Tabla cruzada: prediccion de anomalia vs. fraude real (isFradulent)")
print(tabla_cruzada.to_string())
print()

de_las_anomalas = df[df["es_anomalia"] == 1]
pct_fraude_en_anomalas = (de_las_anomalas["isFradulent"] == "Y").mean() * 100
print(
    f"-> De las {len(de_las_anomalas)} transacciones marcadas como "
    f"anomalas, el {pct_fraude_en_anomalas:.1f}% son fraude real."
)
print()

# ---------------------------------------------------------------
# 5. Guardar resultados para el informe
# ---------------------------------------------------------------
tabla_experimento.to_csv("outputs/punto3_experimento_contamination.csv", index=False)
tabla_cruzada.to_csv("outputs/punto3_tabla_cruzada.csv")
df[variables_features + ["isFradulent", "es_anomalia", "score_anomalia"]].to_csv(
    "outputs/punto3_dataset_con_anomalias.csv", index=False
)

print("Resultados guardados en la carpeta 'outputs/'")