

import pandas as pd
import numpy as np
from sklearn.naive_bayes import GaussianNB
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    confusion_matrix,
    roc_curve,
    roc_auc_score,
    precision_score,
    recall_score,
    f1_score,
)
import matplotlib.pyplot as plt

# ---------------------------------------------------------------
# 1. Carga del dataset limpio
# ---------------------------------------------------------------
RUTA_CSV = "outputs/dataset_limpio.csv"
df = pd.read_csv(RUTA_CSV)

variables_binarias = ["Is declined", "isForeignTransaction", "isHighRiskCountry"]
for col in variables_binarias:
    if not pd.api.types.is_numeric_dtype(df[col]):
        df[col] = df[col].map({"Y": 1, "N": 0})

variables_predictoras = [
    "Average Amount/transaction/day",
    "Transaction_amount",
    "Is declined",
    "Total Number of declines/day",
    "isForeignTransaction",
    "isHighRiskCountry",
    "Daily_chargeback_avg_amt",
    "6_month_avg_chbk_amt",
    "6-month_chbk_freq",
]

X = df[variables_predictoras].to_numpy(dtype=float)
y = (df["isFradulent"] == "Y").to_numpy(dtype=int)  # 1 = fraude, 0 = no fraude

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42, stratify=y
)

print(f"Entrenamiento: {len(X_train)} registros ({y_train.sum()} fraudes)")
print(f"Prueba: {len(X_test)} registros ({y_test.sum()} fraudes)\n")


# ---------------------------------------------------------------
# 2. Naive Bayes Gaussiano implementado a mano
#
#    Teorema de Bayes:
#        P(clase | x1,...,xp) = P(x1,...,xp | clase) * P(clase)
#                                --------------------------------
#                                        P(x1,...,xp)
#
#    Supuesto "naive" (ingenuo): las variables son condicionalmente
#    independientes dada la clase, entonces:
#        P(x1,...,xp | clase) = P(x1|clase) * P(x2|clase) * ... * P(xp|clase)
#
#    Como comparamos las clases entre si, el denominador P(x1,...,xp)
#    es el mismo para ambas clases y se puede omitir (no cambia cual
#    clase gana). Trabajamos en escala logaritmica para evitar
#    "underflow" numerico al multiplicar muchas probabilidades
#    pequenas:
#        log P(clase|x) ~ log P(clase) + sum(log P(xi|clase))
#
#    Cada P(xi|clase) se modela con una densidad normal (Gaussiana):
#        P(xi|clase) = 1/sqrt(2*pi*var) * exp( -(xi-media)^2 / (2*var) )
# ---------------------------------------------------------------
def entrenar_naive_bayes_manual(X, y):
    clases = np.unique(y)
    parametros = {}

    for clase in clases:
        X_clase = X[y == clase]
        parametros[clase] = {
            "prior": len(X_clase) / len(X),  # P(clase)
            "media": X_clase.mean(axis=0),  # media de cada variable
            "varianza": X_clase.var(axis=0) + 1e-9,  # +epsilon evita division por 0
        }
    return parametros


def log_densidad_normal(x, media, varianza):
    """log de la densidad normal, evaluado variable por variable"""
    return -0.5 * np.log(2 * np.pi * varianza) - ((x - media) ** 2) / (2 * varianza)


def predecir_naive_bayes_manual(X, parametros):
    clases = sorted(parametros.keys())
    log_probabilidades = np.zeros((len(X), len(clases)))

    for idx, clase in enumerate(clases):
        prior = parametros[clase]["prior"]
        media = parametros[clase]["media"]
        varianza = parametros[clase]["varianza"]

        # log P(clase) + suma de log P(xi|clase) para cada variable
        log_prob = np.log(prior) + np.sum(
            log_densidad_normal(X, media, varianza), axis=1
        )
        log_probabilidades[:, idx] = log_prob

    predicciones = np.array(clases)[np.argmax(log_probabilidades, axis=1)]

    # Convertimos log-probabilidades a probabilidades normalizadas (0 a 1)
    # usando el truco de restar el maximo antes de exponenciar (estabilidad numerica)
    log_probs_norm = log_probabilidades - log_probabilidades.max(axis=1, keepdims=True)
    probs = np.exp(log_probs_norm)
    probs = probs / probs.sum(axis=1, keepdims=True)

    # probabilidad de la clase "1" (fraude)
    prob_fraude = probs[:, list(clases).index(1)]

    return predicciones, prob_fraude


parametros_manual = entrenar_naive_bayes_manual(X_train, y_train)
y_pred_manual, prob_fraude_manual = predecir_naive_bayes_manual(X_test, parametros_manual)

print("=" * 70)
print("PARAMETROS APRENDIDOS (Naive Bayes manual)")
print("=" * 70)
for clase, p in parametros_manual.items():
    etiqueta = "FRAUDE (1)" if clase == 1 else "NO FRAUDE (0)"
    print(f"Clase {etiqueta}: prior = {p['prior']:.4f}")
print()


# ---------------------------------------------------------------
# 3. Matriz de confusion implementada a mano
#
#    VP = predije fraude Y era fraude
#    FP = predije fraude PERO no era fraude
#    FN = predije no-fraude PERO SI era fraude  <- el mas peligroso
#    VN = predije no-fraude Y no era fraude
# ---------------------------------------------------------------
def matriz_confusion_manual(y_real, y_pred):
    vp = np.sum((y_pred == 1) & (y_real == 1))
    fp = np.sum((y_pred == 1) & (y_real == 0))
    fn = np.sum((y_pred == 0) & (y_real == 1))
    vn = np.sum((y_pred == 0) & (y_real == 0))
    return vp, fp, fn, vn


vp, fp, fn, vn = matriz_confusion_manual(y_test, y_pred_manual)

print("=" * 70)
print("MATRIZ DE CONFUSION (calculo manual)")
print("=" * 70)
print(f"                  Predicho: No-fraude   Predicho: Fraude")
print(f"Real: No-fraude        VN={vn:4d}              FP={fp:4d}")
print(f"Real: Fraude           FN={fn:4d}              VP={vp:4d}")
print()

# Metricas derivadas de la matriz (formulas explicitas)
precision_manual = vp / (vp + fp) if (vp + fp) > 0 else 0
recall_manual = vp / (vp + fn) if (vp + fn) > 0 else 0
f1_manual = (
    2 * precision_manual * recall_manual / (precision_manual + recall_manual)
    if (precision_manual + recall_manual) > 0
    else 0
)
accuracy_manual = (vp + vn) / (vp + vn + fp + fn)

print(f"Accuracy  = (VP+VN)/Total        = {accuracy_manual:.4f}")
print(f"Precision = VP/(VP+FP)           = {precision_manual:.4f}")
print(f"Recall    = VP/(VP+FN)           = {recall_manual:.4f}  <- clave en fraude")
print(f"F1-score  = 2*P*R/(P+R)          = {f1_manual:.4f}")
print()
print(f"Falsos negativos (fraudes que se nos escaparon): {fn} de {vp+fn} fraudes reales")
print()

# ---------------------------------------------------------------
# 4. Verificacion cruzada con sklearn (GaussianNB)
# ---------------------------------------------------------------
modelo_sklearn = GaussianNB()
modelo_sklearn.fit(X_train, y_train)
y_pred_sklearn = modelo_sklearn.predict(X_test)
prob_fraude_sklearn = modelo_sklearn.predict_proba(X_test)[:, 1]

print("=" * 70)
print("VERIFICACION CRUZADA - sklearn.naive_bayes.GaussianNB")
print("=" * 70)
cm_sklearn = confusion_matrix(y_test, y_pred_sklearn)
print("Matriz de confusion (sklearn) [ [VN, FP], [FN, VP] ]:")
print(cm_sklearn)
print(f"Precision (sklearn) = {precision_score(y_test, y_pred_sklearn):.4f}  "
      f"(diferencia: {abs(precision_manual - precision_score(y_test, y_pred_sklearn)):.4f})")
print(f"Recall    (sklearn) = {recall_score(y_test, y_pred_sklearn):.4f}  "
      f"(diferencia: {abs(recall_manual - recall_score(y_test, y_pred_sklearn)):.4f})")
print(f"F1        (sklearn) = {f1_score(y_test, y_pred_sklearn):.4f}  "
      f"(diferencia: {abs(f1_manual - f1_score(y_test, y_pred_sklearn)):.4f})")
print()
print(
    "Nota: puede haber pequenas diferencias porque sklearn aplica un "
    "'var_smoothing' (una constante muy pequena sumada a la varianza) "
    "para evitar inestabilidad numerica, similar en espiritu al "
    "estimador de Laplace que vimos en clase."
)
print()

# ---------------------------------------------------------------
# 5. Curva ROC y AUC (con las probabilidades del modelo manual)
# ---------------------------------------------------------------
fpr, tpr, umbrales = roc_curve(y_test, prob_fraude_manual)
auc_manual = roc_auc_score(y_test, prob_fraude_manual)
auc_sklearn = roc_auc_score(y_test, prob_fraude_sklearn)

print("=" * 70)
print("CURVA ROC Y AUC")
print("=" * 70)
print(f"AUC (modelo manual)   = {auc_manual:.4f}")
print(f"AUC (sklearn GaussianNB) = {auc_sklearn:.4f}")
print(
    "(AUC = 0.5 -> el modelo no discrimina mejor que el azar; "
    "AUC = 1.0 -> modelo perfecto)"
)
print()

fig, ax = plt.subplots(figsize=(7, 6))
ax.plot(fpr, tpr, label=f"Naive Bayes manual (AUC = {auc_manual:.3f})", linewidth=2)
ax.plot([0, 1], [0, 1], linestyle="--", color="gray", label="Azar (AUC = 0.5)")
ax.set_xlabel("Tasa de Falsos Positivos (FPR)")
ax.set_ylabel("Tasa de Verdaderos Positivos (TPR / Recall)")
ax.set_title("Curva ROC - Naive Bayes para deteccion de fraude")
ax.legend()
plt.tight_layout()
plt.savefig("outputs/naive_bayes_curva_roc.png", dpi=150)
plt.close()
print("Curva ROC guardada en: outputs/naive_bayes_curva_roc.png")
print()

# ---------------------------------------------------------------
# 6. Reflexion etica: peso de las variables geograficas
#
#    Comparamos, para cada variable, que tanto se separan las
#    medias entre la clase fraude y no-fraude (en unidades de
#    desviacion estandar conjunta). Cuanto mayor esa separacion,
#    mas "peso" tiene esa variable en la decision del modelo -
#    porque Naive Bayes basa su decision en P(xi|clase), que
#    depende directamente de que tan distintas son esas medias.
# ---------------------------------------------------------------
print("=" * 70)
print("REFLEXION ETICA - separacion de medias entre clases por variable")
print("=" * 70)

separaciones = []
for i, var in enumerate(variables_predictoras):
    media_fraude = parametros_manual[1]["media"][i]
    media_no_fraude = parametros_manual[0]["media"][i]
    var_fraude = parametros_manual[1]["varianza"][i]
    var_no_fraude = parametros_manual[0]["varianza"][i]
    desviacion_conjunta = np.sqrt((var_fraude + var_no_fraude) / 2)
    separacion = abs(media_fraude - media_no_fraude) / desviacion_conjunta

    separaciones.append(
        {
            "variable": var,
            "media_fraude": media_fraude,
            "media_no_fraude": media_no_fraude,
            "separacion_estandarizada": separacion,
        }
    )

tabla_separacion = pd.DataFrame(separaciones).sort_values(
    "separacion_estandarizada", ascending=False
)
print(tabla_separacion.round(3).to_string(index=False))
print()

# Bandera especifica sobre las variables geograficas
sep_pais_riesgo = tabla_separacion[
    tabla_separacion["variable"] == "isHighRiskCountry"
]["separacion_estandarizada"].values[0]
sep_extranjera = tabla_separacion[
    tabla_separacion["variable"] == "isForeignTransaction"
]["separacion_estandarizada"].values[0]

print(
    f"isHighRiskCountry tiene una separacion estandarizada de "
    f"{sep_pais_riesgo:.3f}, e isForeignTransaction de {sep_extranjera:.3f}.\n"
    "Si estas variables geograficas resultan entre las de mayor peso, "
    "el modelo podria estar penalizando de forma desproporcionada a "
    "transacciones legitimas realizadas en el extranjero o en paises "
    "catalogados como 'de alto riesgo', generando friccion injusta a "
    "clientes honestos que simplemente viajan o compran en el exterior. "
    "Esto es un riesgo etico real: el modelo aprende una correlacion "
    "estadistica (pais <-> fraude historico), no una relacion causal, "
    "y aplicarla sin supervision humana puede traducirse en discriminacion "
    "geografica hacia clientes legitimos."
)

# ---------------------------------------------------------------
# 7. Guardar resultados para el informe
# ---------------------------------------------------------------
tabla_metricas_nb = pd.DataFrame(
    {
        "metrica": ["Accuracy", "Precision", "Recall", "F1", "AUC"],
        "valor": [accuracy_manual, precision_manual, recall_manual, f1_manual, auc_manual],
    }
)
tabla_metricas_nb.to_csv("outputs/naive_bayes_metricas.csv", index=False)
tabla_separacion.round(4).to_csv("outputs/naive_bayes_separacion_variables.csv", index=False)

pd.DataFrame(
    {"VN": [vn], "FP": [fp], "FN": [fn], "VP": [vp]}
).to_csv("outputs/naive_bayes_matriz_confusion.csv", index=False)

print("Resultados guardados en la carpeta 'outputs/'")