import pandas as pd
import sys

# Ruta absoluta y fija basada en la ubicación exacta de tu computador
ruta_archivo = r'C:\Users\Asus\OneDrive\Documents\Actividad1_EAA\data\creditcardcsvpresent.csv'

print("--- INICIANDO ANÁLISIS: PUNTO 1A ---")
try:
    df = pd.read_csv(ruta_archivo)
    print("¡Dataset cargado exitosamente desde la carpeta 'data'!\n")
except FileNotFoundError:
    print(f"Error: No se encontró el archivo en la ruta: {ruta_archivo}")
    print("Verifica que el archivo 'creditcardcsvpresent.csv' esté dentro de la carpeta 'data'.")
    sys.exit()

# 1. Estructura general
print("=== 1. ESTRUCTURA GENERAL ===")
print(df.head(), "\n")
df.info()

# 2. Balance de la variable objetivo
print("\n=== 2. BALANCE DE FRAUDE (isFradulent) ===")
print(df['isFradulent'].value_counts())
print(df['isFradulent'].value_counts(normalize=True) * 100)

# 3. Nulos en fecha
print("\n=== 3. NULOS EN 'Transaction date' ===")
print("Cantidad de nulos:", df['Transaction date'].isnull().sum())
print("\n--- ANÁLISIS DEL PUNTO 1A FINALIZADO ---")