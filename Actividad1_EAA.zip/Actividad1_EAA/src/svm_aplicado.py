

import pandas as pd
import numpy as np
import time
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix,
)

# ---------------------------------------------------------------
# 1. Carga del dataset limpio
# ---------------------------------------------------------------
RUTA_CSV = "outputs/dataset_limpio.csv"
df = pd.read_csv(RUTA_CSV)

variables_binarias = ["Is declined", "isForeignTransaction", "isHighRiskCountry"]
for col in variables_binarias:
    if not pd.api.types.is_numeric_dtype(df[col]):
        df[col] = df[col].map({"Y": 1, "N": 0})

variables_predictoras = [
    "Average Amount/transaction/day",
    "Transaction_amount",
    "Is declined",
    "Total Number of declines/day",
    "isForeignTransaction",
    "isHighRiskCountry",
    "Daily_chargeback_avg_amt",
    "6_month_avg_chbk_amt",
    "6-month_chbk_freq",
]

X_completo = df[variables_predictoras].to_numpy(dtype=float)
y_completo = (df["isFradulent"] == "Y").to_numpy(dtype=int)


# ---------------------------------------------------------------
# 2. Muestra estratificada
#    SVM con kernel RBF es computacionalmente costoso (su complejidad
#    crece de forma cuadratica o peor con el numero de muestras,
#    porque compara cada punto contra cada otro punto). Por eso
#    tomamos una muestra mas pequena que CONSERVA la proporcion
#    original de fraude/no-fraude (14.6% / 85.4%).
# ---------------------------------------------------------------
TAMANO_MUESTRA = 800  # de las 3075 filas totales

X_muestra, _, y_muestra, _ = train_test_split(
    X_completo,
    y_completo,
    train_size=TAMANO_MUESTRA,
    random_state=42,
    stratify=y_completo,  # conserva la proporcion 14.6% / 85.4%
)

print("=" * 70)
print("MUESTRA ESTRATIFICADA")
print("=" * 70)
print(f"Tamano de la muestra: {len(X_muestra)} de {len(X_completo)} filas totales")
print(f"Proporcion de fraude en la muestra: {y_muestra.mean()*100:.2f}% "
      f"(original: {y_completo.mean()*100:.2f}%)")
print()

X_train, X_test, y_train, y_test = train_test_split(
    X_muestra, y_muestra, test_size=0.20, random_state=42, stratify=y_muestra
)


# ---------------------------------------------------------------
# 3. Estandarizacion IMPLEMENTADA A MANO (formula explicita)
#
#    z = (x - media) / desviacion_estandar
#
#    Es obligatorio para SVM porque el algoritmo mide DISTANCIAS
#    entre puntos: Transaction_amount llega a 108.000 mientras que
#    isHighRiskCountry es 0 o 1 -- sin estandarizar, la variable de
#    mayor escala dominaria completamente el calculo de distancias,
#    sin importar su relevancia real.
#
#    IMPORTANTE: la media y desviacion se calculan SOLO con los
#    datos de entrenamiento, y se aplican igual al conjunto de
#    prueba (nunca "ver" el test set al calcular estos parametros,
#    para evitar fuga de informacion).
# ---------------------------------------------------------------
def estandarizar_fit(X):
    """Calcula media y desviacion estandar (a partir del set de train)"""
    media = X.mean(axis=0)
    desviacion = X.std(axis=0) + 1e-9  # epsilon evita division por cero
    return media, desviacion


def estandarizar_transform(X, media, desviacion):
    return (X - media) / desviacion


media_train, desviacion_train = estandarizar_fit(X_train)
X_train_std = estandarizar_transform(X_train, media_train, desviacion_train)
X_test_std = estandarizar_transform(X_test, media_train, desviacion_train)

print("=" * 70)
print("ESTANDARIZACION (verificacion)")
print("=" * 70)
print("Media de cada variable DESPUES de estandarizar en train "
      "(debe ser ~0):")
print(np.round(X_train_std.mean(axis=0), 4))
print("Desviacion estandar DESPUES de estandarizar en train "
      "(debe ser ~1):")
print(np.round(X_train_std.std(axis=0), 4))
print()


# =================================================================
# PARTE A - SVM LINEAL vs SVM CON KERNEL RBF
# =================================================================
print("=" * 70)
print("SVM LINEAL vs SVM CON KERNEL RBF")
print("=" * 70)

for kernel in ["linear", "rbf"]:
    inicio = time.time()
    modelo = SVC(kernel=kernel, C=1.0, probability=True, random_state=42)
    modelo.fit(X_train_std, y_train)
    tiempo_entrenamiento = time.time() - inicio

    pred = modelo.predict(X_test_std)
    prob = modelo.predict_proba(X_test_std)[:, 1]

    print(f"\nKernel = {kernel}")
    print(f"  Tiempo de entrenamiento: {tiempo_entrenamiento:.3f} segundos")
    print(f"  Numero de vectores de soporte: {modelo.n_support_.sum()} "
          f"de {len(X_train_std)} puntos de entrenamiento")
    print(f"  Accuracy  = {accuracy_score(y_test, pred):.4f}")
    print(f"  Precision = {precision_score(y_test, pred):.4f}")
    print(f"  Recall    = {recall_score(y_test, pred):.4f}")
    print(f"  F1-score  = {f1_score(y_test, pred):.4f}")
    print(f"  AUC       = {roc_auc_score(y_test, prob):.4f}")
print()


# =================================================================
# PARTE B - EFECTO DEL PARAMETRO C (kernel RBF)
# =================================================================
# C controla el equilibrio entre margen amplio (tolera errores) y
# margen estrecho (clasifica bien cada punto de entrenamiento, con
# mas riesgo de sobreajuste). Probamos varios valores.
# =================================================================
print("=" * 70)
print("EFECTO DEL PARAMETRO C (kernel RBF)")
print("=" * 70)

valores_C = [0.01, 0.1, 1, 10, 100]
resultados_C = []

for C in valores_C:
    modelo = SVC(kernel="rbf", C=C, probability=True, random_state=42)
    modelo.fit(X_train_std, y_train)

    pred_train = modelo.predict(X_train_std)
    pred_test = modelo.predict(X_test_std)

    accuracy_train = accuracy_score(y_train, pred_train)
    accuracy_test = accuracy_score(y_test, pred_test)
    recall_test = recall_score(y_test, pred_test)
    n_vectores_soporte = modelo.n_support_.sum()

    resultados_C.append(
        {
            "C": C,
            "n_vectores_soporte": n_vectores_soporte,
            "accuracy_train": round(accuracy_train, 4),
            "accuracy_test": round(accuracy_test, 4),
            "brecha_train_test": round(accuracy_train - accuracy_test, 4),
            "recall_test": round(recall_test, 4),
        }
    )

tabla_C = pd.DataFrame(resultados_C)
print(tabla_C.to_string(index=False))
print()
print(
    "Lectura: a medida que C aumenta, el numero de vectores de soporte "
    "tiende a bajar (margen mas estricto) y la 'brecha_train_test' "
    "(diferencia entre accuracy de entrenamiento y de prueba) puede "
    "crecer -- eso es la senal de sobreajuste: el modelo empieza a "
    "memorizar el entrenamiento en vez de generalizar."
)
print()


# =================================================================
# PARTE C - BUSQUEDA AUTOMATICA DE LOS MEJORES C Y GAMMA (GridSearchCV)
# =================================================================
print("=" * 70)
print("GRIDSEARCHCV - busqueda de mejores hiperparametros (C y gamma)")
print("=" * 70)

grilla_parametros = {
    "C": [0.1, 1, 10, 100],
    "gamma": [0.001, 0.01, 0.1, 1],
}

busqueda = GridSearchCV(
    SVC(kernel="rbf", probability=True, random_state=42),
    grilla_parametros,
    cv=5,  # validacion cruzada 5-fold, igual que se vio en clase
    scoring="recall",  # optimizamos recall, la metrica critica en fraude
    n_jobs=-1,
)
busqueda.fit(X_train_std, y_train)

print(f"Mejores hiperparametros encontrados: {busqueda.best_params_}")
print(f"Mejor recall promedio en validacion cruzada: {busqueda.best_score_:.4f}")
print()

# Evaluacion final con los mejores hiperparametros, sobre el test set
mejor_modelo = busqueda.best_estimator_
pred_final = mejor_modelo.predict(X_test_std)
prob_final = mejor_modelo.predict_proba(X_test_std)[:, 1]

print("=" * 70)
print("MODELO FINAL SVM (con mejores C y gamma) - evaluacion en test")
print("=" * 70)
print(f"Accuracy  = {accuracy_score(y_test, pred_final):.4f}")
print(f"Precision = {precision_score(y_test, pred_final):.4f}")
print(f"Recall    = {recall_score(y_test, pred_final):.4f}")
print(f"F1-score  = {f1_score(y_test, pred_final):.4f}")
print(f"AUC       = {roc_auc_score(y_test, prob_final):.4f}")
print()

matriz_conf = confusion_matrix(y_test, pred_final)
print("Matriz de confusion [ [VN, FP], [FN, VP] ]:")
print(matriz_conf)
print()

# ---------------------------------------------------------------
# Guardar resultados para el informe
# ---------------------------------------------------------------
tabla_C.to_csv("outputs/svm_efecto_parametro_C.csv", index=False)

resumen_final = pd.DataFrame(
    [
        {
            "modelo": "SVM RBF (mejores hiperparametros)",
            "C": busqueda.best_params_["C"],
            "gamma": busqueda.best_params_["gamma"],
            "accuracy": accuracy_score(y_test, pred_final),
            "precision": precision_score(y_test, pred_final),
            "recall": recall_score(y_test, pred_final),
            "f1": f1_score(y_test, pred_final),
            "auc": roc_auc_score(y_test, prob_final),
        }
    ]
)
resumen_final.to_csv("outputs/svm_modelo_final.csv", index=False)

print("Resultados guardados en la carpeta 'outputs/'")