

import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split

# ---------------------------------------------------------------
# 1. Carga del dataset limpio
# ---------------------------------------------------------------
RUTA_CSV = "outputs/dataset_limpio.csv"
df = pd.read_csv(RUTA_CSV)

variables_binarias = ["Is declined", "isForeignTransaction", "isHighRiskCountry"]
for col in variables_binarias:
    if not pd.api.types.is_numeric_dtype(df[col]):
        df[col] = df[col].map({"Y": 1, "N": 0})

# ---------------------------------------------------------------
# 2. Definicion de variable objetivo (y) y predictoras (X)
#    Predecimos Transaction_amount a partir del comportamiento
#    historico y de riesgo del comercio (NO usamos isFradulent
#    aqui, porque en la practica esa etiqueta no se conoce ANTES
#    de que ocurra la transaccion; usarla seria fuga de informacion
#    para este problema de regresion).
# ---------------------------------------------------------------
variable_objetivo = "Transaction_amount"
variables_predictoras = [
    "Average Amount/transaction/day",
    "Is declined",
    "Total Number of declines/day",
    "isForeignTransaction",
    "isHighRiskCountry",
    "Daily_chargeback_avg_amt",
    "6_month_avg_chbk_amt",
    "6-month_chbk_freq",
]

X = df[variables_predictoras].to_numpy(dtype=float)
y = df[variable_objetivo].to_numpy(dtype=float)

# ---------------------------------------------------------------
# 3. Particion entrenamiento / prueba (80% / 20%, misma logica
#    que uso el profesor en clase con random_state=42)
# ---------------------------------------------------------------
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42
)

print(f"Registros de entrenamiento: {len(X_train)}")
print(f"Registros de prueba: {len(X_test)}\n")


# ---------------------------------------------------------------
# 4. Regresion lineal multiple - ECUACION NORMAL implementada a mano
#
#    El modelo de regresion lineal multiple es:
#        y = b0 + b1*x1 + b2*x2 + ... + bp*xp
#
#    En notacion matricial, agregando una columna de 1's a X para
#    el intercepto b0:
#        y = X_ext * beta
#
#    La solucion que minimiza el error cuadratico (minimos cuadrados
#    ordinarios, OLS) tiene forma cerrada, la ECUACION NORMAL:
#
#        beta = (X_ext^T * X_ext)^(-1) * X_ext^T * y
#
#    donde X_ext^T es la transpuesta de X_ext y ^(-1) es la matriz
#    inversa.
# ---------------------------------------------------------------
def ajustar_regresion_lineal_manual(X, y):
    n = X.shape[0]
    # Agregamos una columna de 1's al inicio para el intercepto (b0)
    X_ext = np.hstack([np.ones((n, 1)), X])

    # beta = (X_ext^T X_ext)^-1 X_ext^T y
    XtX = X_ext.T @ X_ext
    XtX_inv = np.linalg.inv(XtX)
    Xty = X_ext.T @ y
    beta = XtX_inv @ Xty

    return beta  # beta[0] = intercepto, beta[1:] = coeficientes


def predecir_manual(X, beta):
    n = X.shape[0]
    X_ext = np.hstack([np.ones((n, 1)), X])
    return X_ext @ beta


beta_manual = ajustar_regresion_lineal_manual(X_train, y_train)

print("=" * 70)
print("COEFICIENTES DEL MODELO (ecuacion normal, calculo manual)")
print("=" * 70)
print(f"Intercepto (b0): {beta_manual[0]:,.4f}")
for nombre, coef in zip(variables_predictoras, beta_manual[1:]):
    print(f"  {nombre}: {coef:,.4f}")
print()

y_pred_manual = predecir_manual(X_test, beta_manual)


# ---------------------------------------------------------------
# 5. Metricas de evaluacion implementadas a mano
#
#    MAE  = (1/n) * sum(|y_real - y_pred|)
#    RMSE = sqrt( (1/n) * sum((y_real - y_pred)^2) )
#    R^2  = 1 - (SS_residual / SS_total)
#           SS_residual = sum((y_real - y_pred)^2)
#           SS_total    = sum((y_real - y_media)^2)
# ---------------------------------------------------------------
def mae_manual(y_real, y_pred):
    return np.mean(np.abs(y_real - y_pred))


def rmse_manual(y_real, y_pred):
    return np.sqrt(np.mean((y_real - y_pred) ** 2))


def r2_manual(y_real, y_pred):
    ss_residual = np.sum((y_real - y_pred) ** 2)
    ss_total = np.sum((y_real - np.mean(y_real)) ** 2)
    return 1 - (ss_residual / ss_total)


mae_val = mae_manual(y_test, y_pred_manual)
rmse_val = rmse_manual(y_test, y_pred_manual)
r2_val = r2_manual(y_test, y_pred_manual)

print("=" * 70)
print("METRICAS - calculadas manualmente (sobre el conjunto de PRUEBA)")
print("=" * 70)
print(f"MAE  = {mae_val:,.2f}")
print(f"RMSE = {rmse_val:,.2f}")
print(f"R^2  = {r2_val:.4f}")
print()

# ---------------------------------------------------------------
# 6. Verificacion cruzada con scikit-learn
# ---------------------------------------------------------------
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

modelo_sklearn = LinearRegression()
modelo_sklearn.fit(X_train, y_train)
y_pred_sklearn = modelo_sklearn.predict(X_test)

print("=" * 70)
print("VERIFICACION CRUZADA - sklearn.linear_model.LinearRegression")
print("=" * 70)
print(f"Intercepto (sklearn): {modelo_sklearn.intercept_:,.4f}")
print(f"Diferencia de intercepto manual vs sklearn: "
      f"{abs(beta_manual[0] - modelo_sklearn.intercept_):.8f}")
print()
mae_sk = mean_absolute_error(y_test, y_pred_sklearn)
rmse_sk = np.sqrt(mean_squared_error(y_test, y_pred_sklearn))
r2_sk = r2_score(y_test, y_pred_sklearn)
print(f"MAE  (sklearn) = {mae_sk:,.2f}   |  diferencia = {abs(mae_val - mae_sk):.8f}")
print(f"RMSE (sklearn) = {rmse_sk:,.2f}   |  diferencia = {abs(rmse_val - rmse_sk):.8f}")
print(f"R^2  (sklearn) = {r2_sk:.4f}   |  diferencia = {abs(r2_val - r2_sk):.8f}")
print()

# ---------------------------------------------------------------
# 7. Interpretacion de las metricas en contexto del negocio
# ---------------------------------------------------------------
rango_variable = y.max() - y.min()
print("=" * 70)
print("INTERPRETACION EN CONTEXTO")
print("=" * 70)
print(f"Rango de Transaction_amount en el dataset: {y.min():,.0f} a {y.max():,.0f} "
      f"(rango = {rango_variable:,.0f})")
print(f"El RMSE ({rmse_val:,.2f}) representa aproximadamente el "
      f"{rmse_val / rango_variable * 100:.1f}% del rango total de la variable.")
print(f"El R^2 de {r2_val:.4f} significa que el modelo explica el "
      f"{r2_val*100:.1f}% de la variabilidad de Transaction_amount con "
      f"estas variables predictoras.")
print()

# ---------------------------------------------------------------
# 8. Guardar resultados para el informe
# ---------------------------------------------------------------
tabla_coeficientes = pd.DataFrame(
    {
        "variable": ["Intercepto"] + variables_predictoras,
        "coeficiente": beta_manual,
    }
)
tabla_coeficientes.to_csv("outputs/regresion_coeficientes.csv", index=False)

tabla_metricas = pd.DataFrame(
    {
        "metrica": ["MAE", "RMSE", "R2"],
        "valor_manual": [mae_val, rmse_val, r2_val],
        "valor_sklearn": [mae_sk, rmse_sk, r2_sk],
    }
)
tabla_metricas.to_csv("outputs/regresion_metricas.csv", index=False)

print("Resultados guardados en la carpeta 'outputs/'")