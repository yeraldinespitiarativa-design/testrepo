

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# ---------------------------------------------------------------
# 1. Carga del dataset
# ---------------------------------------------------------------
RUTA_CSV = "data/creditcardcsvpresent.csv"
df = pd.read_csv(RUTA_CSV)

# ---------------------------------------------------------------
# 2. Variables a incluir en la matriz de correlacion.
#    Incluimos Merchant_id a proposito: es nuestro "control negativo",
#    esperamos que NO correlacione con nada (es solo un identificador),
#    y eso mismo es evidencia que respalda excluirlo del modelado.
# ---------------------------------------------------------------
variables_correlacion = [
    "Merchant_id",
    "Average Amount/transaction/day",
    "Transaction_amount",
    "Total Number of declines/day",
    "Daily_chargeback_avg_amt",
    "6_month_avg_chbk_amt",
    "6-month_chbk_freq",
]

datos = df[variables_correlacion].dropna()


# ---------------------------------------------------------------
# 3. Correlacion de Pearson implementada a mano (formula explicita)
#
#    r_xy = sum((xi - x_media) * (yi - y_media))
#           -----------------------------------------
#           sqrt( sum((xi - x_media)^2) * sum((yi - y_media)^2) )
# ---------------------------------------------------------------
def correlacion_pearson_manual(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    x_media = np.mean(x)
    y_media = np.mean(y)

    numerador = np.sum((x - x_media) * (y - y_media))
    denominador = np.sqrt(np.sum((x - x_media) ** 2) * np.sum((y - y_media) ** 2))

    return numerador / denominador


def matriz_correlacion_manual(dataframe):
    columnas = dataframe.columns
    n = len(columnas)
    matriz = pd.DataFrame(np.zeros((n, n)), index=columnas, columns=columnas)

    for i, col_i in enumerate(columnas):
        for j, col_j in enumerate(columnas):
            matriz.iloc[i, j] = correlacion_pearson_manual(
                dataframe[col_i], dataframe[col_j]
            )
    return matriz


# ---------------------------------------------------------------
# 4. Calculo manual
# ---------------------------------------------------------------
matriz_manual = matriz_correlacion_manual(datos)

print("=" * 70)
print("MATRIZ DE CORRELACION - calculada manualmente (formula de Pearson)")
print("=" * 70)
print(matriz_manual.round(3).to_string())
print()

# ---------------------------------------------------------------
# 5. Verificacion cruzada contra pandas.corr()
# ---------------------------------------------------------------
matriz_pandas = datos.corr(method="pearson")

print("=" * 70)
print("VERIFICACION CRUZADA - pandas.corr()")
print("=" * 70)
print(matriz_pandas.round(3).to_string())
print()

diferencia_maxima = (matriz_manual - matriz_pandas).abs().to_numpy().max()
print(f"Diferencia maxima entre calculo manual y pandas.corr(): {diferencia_maxima:.10f}")
print("(deberia ser practicamente cero, del orden del error de punto flotante)")
print()

# ---------------------------------------------------------------
# 6. Identificar los pares mas correlacionados (excluyendo la diagonal)
# ---------------------------------------------------------------
pares = []
columnas = matriz_manual.columns
for i in range(len(columnas)):
    for j in range(i + 1, len(columnas)):
        pares.append(
            {
                "variable_1": columnas[i],
                "variable_2": columnas[j],
                "correlacion": matriz_manual.iloc[i, j],
            }
        )

tabla_pares = pd.DataFrame(pares).sort_values(
    "correlacion", key=abs, ascending=False
)

print("=" * 70)
print("PARES DE VARIABLES ORDENADOS POR CORRELACION ABSOLUTA (mayor a menor)")
print("=" * 70)
print(tabla_pares.round(3).to_string(index=False))
print()

# Bandera de multicolinealidad: pares con |r| > 0.85
umbral_multicolinealidad = 0.85
pares_multicolineales = tabla_pares[tabla_pares["correlacion"].abs() > umbral_multicolinealidad]

print(f"Pares con |correlacion| > {umbral_multicolinealidad} (posible multicolinealidad):")
if len(pares_multicolineales) > 0:
    print(pares_multicolineales.round(3).to_string(index=False))
else:
    print("Ninguno.")
print()

# ---------------------------------------------------------------
# 7. Mapa de calor (heatmap)
# ---------------------------------------------------------------
fig, ax = plt.subplots(figsize=(9, 7))
cax = ax.imshow(matriz_manual.values, cmap="coolwarm", vmin=-1, vmax=1)

ax.set_xticks(range(len(columnas)))
ax.set_yticks(range(len(columnas)))
ax.set_xticklabels(columnas, rotation=45, ha="right")
ax.set_yticklabels(columnas)

# Anotar cada celda con el valor numerico
for i in range(len(columnas)):
    for j in range(len(columnas)):
        valor = matriz_manual.iloc[i, j]
        color_texto = "white" if abs(valor) > 0.5 else "black"
        ax.text(j, i, f"{valor:.2f}", ha="center", va="center", color=color_texto, fontsize=8)

fig.colorbar(cax, label="Correlacion de Pearson")
ax.set_title("Mapa de calor - Matriz de correlacion (Punto 1b)")
plt.tight_layout()

RUTA_FIGURA = "outputs/punto_1b_mapa_calor.png"
plt.savefig(RUTA_FIGURA, dpi=150)
print(f"Mapa de calor guardado en: {RUTA_FIGURA}")
plt.close()

# ---------------------------------------------------------------
# 8. Guardar la matriz para el informe
# ---------------------------------------------------------------
matriz_manual.round(4).to_csv("outputs/punto_1b_matriz_correlacion.csv")
tabla_pares.round(4).to_csv("outputs/punto_1b_pares_ordenados.csv", index=False)
print("Matriz y tabla de pares guardadas en la carpeta 'outputs/'")