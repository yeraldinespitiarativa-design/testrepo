

import pandas as pd
import numpy as np
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
import matplotlib.pyplot as plt
import shap

# ---------------------------------------------------------------
# 1. Carga del dataset limpio
# ---------------------------------------------------------------
RUTA_CSV = "outputs/dataset_limpio.csv"
df = pd.read_csv(RUTA_CSV)

variables_binarias = ["Is declined", "isForeignTransaction", "isHighRiskCountry"]
for col in variables_binarias:
    if not pd.api.types.is_numeric_dtype(df[col]):
        df[col] = df[col].map({"Y": 1, "N": 0})

variables_predictoras = [
    "Average Amount/transaction/day",
    "Transaction_amount",
    "Is declined",
    "Total Number of declines/day",
    "isForeignTransaction",
    "isHighRiskCountry",
    "Daily_chargeback_avg_amt",
    "6_month_avg_chbk_amt",
    "6-month_chbk_freq",
]

X_df = df[variables_predictoras]
X = X_df.to_numpy(dtype=float)
y = (df["isFradulent"] == "Y").to_numpy(dtype=int)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42, stratify=y
)


# ---------------------------------------------------------------
# 2. Formulas de impureza implementadas a mano
# ---------------------------------------------------------------
def gini_manual(y):
    if len(y) == 0:
        return 0
    _, conteos = np.unique(y, return_counts=True)
    proporciones = conteos / len(y)
    return 1 - np.sum(proporciones**2)


def entropia_manual(y):
    if len(y) == 0:
        return 0
    _, conteos = np.unique(y, return_counts=True)
    proporciones = conteos / len(y)
    proporciones = proporciones[proporciones > 0]
    return -np.sum(proporciones * np.log2(proporciones))


def evaluar_corte(X_col, y, umbral, metrica_impureza):
    izquierda = y[X_col <= umbral]
    derecha = y[X_col > umbral]
    n = len(y)

    impureza_izq = metrica_impureza(izquierda)
    impureza_der = metrica_impureza(derecha)

    impureza_ponderada = (len(izquierda) / n) * impureza_izq + (
        len(derecha) / n
    ) * impureza_der

    return metrica_impureza(y) - impureza_ponderada


# ---------------------------------------------------------------
# 3. Nodo raiz (calculo manual)
# ---------------------------------------------------------------
print("=" * 70)
print("BUSQUEDA DE LA MEJOR PREGUNTA PARA EL NODO RAIZ (calculo manual)")
print("=" * 70)

gini_raiz = gini_manual(y_train)
entropia_raiz = entropia_manual(y_train)
print(f"Impureza del nodo raiz -> Gini = {gini_raiz:.4f} | Entropia = {entropia_raiz:.4f}\n")

mejores_ganancias = []
for idx, var in enumerate(variables_predictoras):
    columna = X_train[:, idx]
    umbrales_candidatos = np.unique(np.percentile(columna, [10, 25, 50, 75, 90]))

    mejor_ganancia_var = -np.inf
    mejor_umbral_var = None
    for umbral in umbrales_candidatos:
        ganancia = evaluar_corte(columna, y_train, umbral, gini_manual)
        if ganancia > mejor_ganancia_var:
            mejor_ganancia_var = ganancia
            mejor_umbral_var = umbral

    mejores_ganancias.append(
        {"variable": var, "mejor_umbral": mejor_umbral_var, "ganancia_gini": mejor_ganancia_var}
    )

tabla_ganancias = pd.DataFrame(mejores_ganancias).sort_values(
    "ganancia_gini", ascending=False
)
print(tabla_ganancias.round(4).to_string(index=False))
print()


# ---------------------------------------------------------------
# 4. Entrenar el arbol con sklearn
# ---------------------------------------------------------------
modelo_arbol = DecisionTreeClassifier(
    criterion="gini", max_depth=4, min_samples_leaf=15, random_state=42
)
modelo_arbol.fit(X_train, y_train)
y_pred = modelo_arbol.predict(X_test)

print("=" * 70)
print("VERIFICACION CRUZADA - DecisionTreeClassifier (sklearn)")
print("=" * 70)
print(f"Variable elegida como raiz por sklearn: "
      f"{variables_predictoras[modelo_arbol.tree_.feature[0]]} "
      f"<= {modelo_arbol.tree_.threshold[0]:.2f}\n")
print(f"Accuracy  = {accuracy_score(y_test, y_pred):.4f}")
print(f"Precision = {precision_score(y_test, y_pred):.4f}")
print(f"Recall    = {recall_score(y_test, y_pred):.4f}")
print(f"F1-score  = {f1_score(y_test, y_pred):.4f}\n")


# ---------------------------------------------------------------
# 5. Visualizar el arbol
# ---------------------------------------------------------------
fig, ax = plt.subplots(figsize=(20, 10))
plot_tree(
    modelo_arbol,
    feature_names=variables_predictoras,
    class_names=["No fraude", "Fraude"],
    filled=True,
    rounded=True,
    fontsize=8,
    ax=ax,
)
plt.tight_layout()
plt.savefig("outputs/xai_arbol_decision.png", dpi=150)
plt.close()
print("Arbol de decision guardado en: outputs/xai_arbol_decision.png\n")


# ---------------------------------------------------------------
# 6. SHAP real (TreeExplainer)
# ---------------------------------------------------------------
explicador = shap.TreeExplainer(modelo_arbol)
explicacion = explicador(X_test)

valores_shap = explicacion.values
if valores_shap.ndim == 3:
    shap_fraude = valores_shap[:, :, 1]
else:
    shap_fraude = valores_shap

importancia_shap = np.abs(shap_fraude).mean(axis=0)
tabla_shap = pd.DataFrame(
    {"variable": variables_predictoras, "importancia_shap_promedio": importancia_shap}
).sort_values("importancia_shap_promedio", ascending=False)

print("=" * 70)
print("IMPORTANCIA DE VARIABLES SEGUN SHAP")
print("=" * 70)
print(tabla_shap.round(4).to_string(index=False))
print()


# ---------------------------------------------------------------
# 7. Graficos nativos de SHAP
# ---------------------------------------------------------------
plt.figure(figsize=(8, 6))
shap.summary_plot(
    shap_fraude, X_test, feature_names=variables_predictoras,
    plot_type="bar", show=False
)
plt.tight_layout()
plt.savefig("outputs/xai_shap_importancia.png", dpi=150)
plt.close()

plt.figure(figsize=(8, 6))
shap.summary_plot(
    shap_fraude, X_test, feature_names=variables_predictoras, show=False
)
plt.tight_layout()
plt.savefig("outputs/xai_shap_beeswarm.png", dpi=150)
plt.close()
print("Graficos SHAP (barras y beeswarm) guardados en outputs/\n")


# ---------------------------------------------------------------
# 8. Caso individual y Waterfall
# ---------------------------------------------------------------
idx_ejemplo = np.where(y_test == 1)[0][0]
contribuciones = pd.DataFrame(
    {
        "variable": variables_predictoras,
        "valor_del_caso": X_test[idx_ejemplo],
        "contribucion_shap": shap_fraude[idx_ejemplo],
    }
).sort_values("contribucion_shap", key=abs, ascending=False)

plt.figure(figsize=(9, 6))
shap.plots.waterfall(explicacion[idx_ejemplo, :, 1], show=False)
plt.tight_layout()
plt.savefig("outputs/xai_shap_waterfall_caso.png", dpi=150)
plt.close()
print("Grafico de cascada (caso individual) guardado en: outputs/xai_shap_waterfall_caso.png\n")


# ---------------------------------------------------------------
# 9. Guardar resultados CSV
# ---------------------------------------------------------------
tabla_ganancias.round(4).to_csv("outputs/xai_ganancias_nodo_raiz.csv", index=False)
tabla_shap.round(4).to_csv("outputs/xai_shap_importancia.csv", index=False)
contribuciones.round(4).to_csv("outputs/xai_shap_caso_individual.csv", index=False)

print("Resultados guardados en la carpeta 'outputs/' exitosamente.")