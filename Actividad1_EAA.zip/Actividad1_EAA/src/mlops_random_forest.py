

import pandas as pd
import numpy as np
import json
import hashlib
import joblib
from datetime import datetime, timezone
from pathlib import Path
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

# ---------------------------------------------------------------
# 1. Carga del dataset limpio
# ---------------------------------------------------------------
RUTA_CSV = "outputs/dataset_limpio.csv"
df = pd.read_csv(RUTA_CSV)

variables_binarias = ["Is declined", "isForeignTransaction", "isHighRiskCountry"]
for col in variables_binarias:
    if not pd.api.types.is_numeric_dtype(df[col]):
        df[col] = df[col].map({"Y": 1, "N": 0})

variables_predictoras = [
    "Average Amount/transaction/day",
    "Transaction_amount",
    "Is declined",
    "Total Number of declines/day",
    "isForeignTransaction",
    "isHighRiskCountry",
    "Daily_chargeback_avg_amt",
    "6_month_avg_chbk_amt",
    "6-month_chbk_freq",
]

X = df[variables_predictoras].to_numpy(dtype=float)
y = (df["isFradulent"] == "Y").to_numpy(dtype=int)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42, stratify=y
)


# =================================================================
# PARTE A - RANDOM FOREST: BAGGING IMPLEMENTADO A MANO
# =================================================================
#
# Un Random Forest combina dos fuentes de aleatoriedad (igual que
# vimos en clase con el ejemplo de fiebre/tos):
#   1) Bootstrap: cada arbol ve una muestra distinta de los datos,
#      tomada CON reemplazo y del mismo tamano que el original.
#   2) Seleccion aleatoria de variables: cada arbol solo puede ver
#      un subconjunto aleatorio de las variables disponibles (por
#      defecto, sqrt(n_variables) para clasificacion).
# La prediccion final es un VOTO MAYORITARIO entre todos los arboles.
# =================================================================
class RandomForestManual:
    def __init__(self, n_arboles=100, max_depth=6, semilla=42):
        self.n_arboles = n_arboles
        self.max_depth = max_depth
        self.semilla = semilla
        self.arboles = []  # lista de (arbol_entrenado, indices_de_variables_usadas)

    def fit(self, X, y):
        rng = np.random.default_rng(self.semilla)
        n_muestras, n_variables = X.shape
        n_variables_por_split = max(1, int(np.sqrt(n_variables)))

        self.arboles = []
        for i in range(self.n_arboles):
            # 1) Muestra bootstrap (con reemplazo, mismo tamano que el original)
            indices_bootstrap = rng.integers(0, n_muestras, size=n_muestras)
            X_bootstrap = X[indices_bootstrap]
            y_bootstrap = y[indices_bootstrap]

            # 2) Subconjunto aleatorio de variables para este arbol
            variables_elegidas = rng.choice(
                n_variables, size=n_variables_por_split, replace=False
            )
            X_bootstrap_reducido = X_bootstrap[:, variables_elegidas]

            # Entrenamos un arbol de decision simple sobre esta muestra
            arbol = DecisionTreeClassifier(
                max_depth=self.max_depth, random_state=self.semilla + i
            )
            arbol.fit(X_bootstrap_reducido, y_bootstrap)

            self.arboles.append((arbol, variables_elegidas))

        return self

    def predict_proba(self, X):
        """Probabilidad de fraude = proporcion de arboles que votan 'fraude'"""
        votos = np.zeros((len(X), self.n_arboles))
        for i, (arbol, variables_elegidas) in enumerate(self.arboles):
            X_reducido = X[:, variables_elegidas]
            votos[:, i] = arbol.predict(X_reducido)

        return votos.mean(axis=1)  # proporcion de votos "fraude"

    def predict(self, X, umbral=0.5):
        return (self.predict_proba(X) >= umbral).astype(int)


print("=" * 70)
print("RANDOM FOREST - BAGGING IMPLEMENTADO A MANO (100 arboles)")
print("=" * 70)
rf_manual = RandomForestManual(n_arboles=100, max_depth=6, semilla=42)
rf_manual.fit(X_train, y_train)
y_pred_manual = rf_manual.predict(X_test)

print(f"Accuracy  = {accuracy_score(y_test, y_pred_manual):.4f}")
print(f"Precision = {precision_score(y_test, y_pred_manual):.4f}")
print(f"Recall    = {recall_score(y_test, y_pred_manual):.4f}")
print(f"F1-score  = {f1_score(y_test, y_pred_manual):.4f}")
print()

# ---------------------------------------------------------------
# Verificacion cruzada con sklearn.RandomForestClassifier
# ---------------------------------------------------------------
modelo_sklearn_rf = RandomForestClassifier(
    n_estimators=100, max_depth=6, random_state=42
)
modelo_sklearn_rf.fit(X_train, y_train)
y_pred_sklearn = modelo_sklearn_rf.predict(X_test)

print("=" * 70)
print("VERIFICACION CRUZADA - sklearn.ensemble.RandomForestClassifier")
print("=" * 70)
print(f"Accuracy  = {accuracy_score(y_test, y_pred_sklearn):.4f}")
print(f"Precision = {precision_score(y_test, y_pred_sklearn):.4f}")
print(f"Recall    = {recall_score(y_test, y_pred_sklearn):.4f}")
print(f"F1-score  = {f1_score(y_test, y_pred_sklearn):.4f}")
print(
    "\n(los resultados no seran identicos byte a byte porque sklearn "
    "usa una implementacion en C mas sofisticada -Gini optimizado, "
    "distinto generador aleatorio internamente-, pero el desempeno "
    "deberia ser muy similar, confirmando que la logica de bagging "
    "implementada a mano es correcta)"
)
print()

# El modelo que llevaremos a "produccion" es el de sklearn (mas
# eficiente y el estandar de la industria); el manual fue para
# demostrar el entendimiento del algoritmo.
modelo_produccion = modelo_sklearn_rf


# =================================================================
# PARTE B - SERIALIZACION
# =================================================================
# Guardamos el modelo ya entrenado en disco para poder cargarlo
# despues SIN tener que reentrenarlo. Usamos joblib (mas eficiente
# que pickle puro para objetos de sklearn con arrays de NumPy).
# =================================================================
print("=" * 70)
print("SERIALIZACION DEL MODELO")
print("=" * 70)

CARPETA_MODELOS = Path("outputs/modelos")
CARPETA_MODELOS.mkdir(parents=True, exist_ok=True)

RUTA_MODELO = CARPETA_MODELOS / "random_forest_fraude_v1.joblib"
joblib.dump(modelo_produccion, RUTA_MODELO)
print(f"Modelo guardado en: {RUTA_MODELO}")

# Verificacion: cargar el modelo y confirmar que predice IGUAL
modelo_cargado = joblib.load(RUTA_MODELO)
y_pred_cargado = modelo_cargado.predict(X_test)
predicciones_identicas = np.array_equal(y_pred_sklearn, y_pred_cargado)
print(f"Verificacion: el modelo cargado predice identico al original? "
      f"{predicciones_identicas}")
print()


# =================================================================
# PARTE C - VERSIONADO
# =================================================================
# Guardamos METADATOS junto al modelo: version, fecha, hiperparametros,
# hash de los datos de entrenamiento (para saber EXACTAMENTE con que
# datos se entreno esta version si el CSV cambia mas adelante) y las
# metricas obtenidas. Esto permite rastrear cambios y revertir si
# una version nueva se desempena peor.
# =================================================================
print("=" * 70)
print("VERSIONADO - METADATOS DEL MODELO")
print("=" * 70)


def calcular_hash_datos(ruta_csv):
    """Hash MD5 del archivo de datos, para saber si cambio entre versiones"""
    with open(ruta_csv, "rb") as f:
        contenido = f.read()
    return hashlib.md5(contenido).hexdigest()


metadatos = {
    "nombre_modelo": "random_forest_fraude",
    "version": "v1",
    "fecha_entrenamiento": datetime.now(timezone.utc).isoformat(),
    "hash_datos_entrenamiento": calcular_hash_datos(RUTA_CSV),
    "hiperparametros": {
        "n_estimators": 100,
        "max_depth": 6,
        "random_state": 42,
    },
    "variables_predictoras": variables_predictoras,
    "metricas_test": {
        "accuracy": round(accuracy_score(y_test, y_pred_sklearn), 4),
        "precision": round(precision_score(y_test, y_pred_sklearn), 4),
        "recall": round(recall_score(y_test, y_pred_sklearn), 4),
        "f1": round(f1_score(y_test, y_pred_sklearn), 4),
    },
    "n_registros_entrenamiento": len(X_train),
    "n_registros_prueba": len(X_test),
}

RUTA_METADATOS = CARPETA_MODELOS / "random_forest_fraude_v1_metadata.json"
with open(RUTA_METADATOS, "w", encoding="utf-8") as f:
    json.dump(metadatos, f, indent=2, ensure_ascii=False)

print(f"Metadatos guardados en: {RUTA_METADATOS}")
print(json.dumps(metadatos, indent=2, ensure_ascii=False))
print()


# =================================================================
# PARTE D - MONITORIZACION BASICA (DRIFT)
# =================================================================
# En produccion, el comportamiento de los comercios puede cambiar
# con el tiempo (nuevos patrones de fraude, cambios de mercado).
# Simulamos esto: tomamos un "lote nuevo" de datos (aqui, una
# submuestra distinta del propio dataset para ilustrar el metodo) y
# comparamos la media de cada variable contra la media de
# entrenamiento, usando un z-score. Si el z-score supera un umbral,
# se marca como posible drift y se sugiere revisar/reentrenar.
# =================================================================
print("=" * 70)
print("MONITORIZACION BASICA - DETECCION DE DRIFT")
print("=" * 70)


def detectar_drift(X_referencia, X_nuevo, nombres_variables, umbral_z=2.0):
    media_ref = X_referencia.mean(axis=0)
    std_ref = X_referencia.std(axis=0) + 1e-9
    media_nuevo = X_nuevo.mean(axis=0)

    z_scores = (media_nuevo - media_ref) / std_ref

    resultado = pd.DataFrame(
        {
            "variable": nombres_variables,
            "media_entrenamiento": media_ref,
            "media_lote_nuevo": media_nuevo,
            "z_score": z_scores,
            "posible_drift": np.abs(z_scores) > umbral_z,
        }
    )
    return resultado


# Simulacion: tomamos el conjunto de prueba como "lote nuevo que llega
# despues" (en un caso real, seria un lote de transacciones de la
# semana siguiente, aun sin usar en el entrenamiento)
reporte_drift = detectar_drift(X_train, X_test, variables_predictoras, umbral_z=2.0)
print(reporte_drift.round(3).to_string(index=False))
print()

n_variables_con_drift = reporte_drift["posible_drift"].sum()
if n_variables_con_drift == 0:
    print(
        "-> No se detecto drift significativo: el lote nuevo tiene una "
        "distribucion similar a la de entrenamiento. El modelo puede "
        "seguir usandose con confianza."
    )
else:
    print(
        f"-> ALERTA: {n_variables_con_drift} variable(s) muestran una "
        "desviacion significativa respecto al entrenamiento. Se "
        "recomienda investigar la causa y considerar reentrenar el "
        "modelo con datos mas recientes."
    )

reporte_drift.round(4).to_csv("outputs/mlops_reporte_drift.csv", index=False)

print("\nResultados y modelo guardados en 'outputs/modelos/' y 'outputs/'")