

import pandas as pd
import numpy as np

# ---------------------------------------------------------------
# 1. Carga del dataset YA LIMPIO (salida del paso de missing)
# ---------------------------------------------------------------
RUTA_CSV = "outputs/dataset_limpio.csv"
df = pd.read_csv(RUTA_CSV)

# ---------------------------------------------------------------
# 2. Preparacion de variables para el agrupamiento
#    - Excluimos Merchant_id (identificador, no clusteriza) y
#      isFradulent (es la etiqueta; K-means es NO supervisado y
#      no debe usarla para agrupar, solo la usaremos despues para
#      interpretar los grupos resultantes).
#    - Codificamos las variables binarias Y/N como 1/0.
# ---------------------------------------------------------------
variables_binarias = ["Is declined", "isForeignTransaction", "isHighRiskCountry"]
for col in variables_binarias:
    df[col] = df[col].map({"Y": 1, "N": 0})

variables_clustering = [
    "Average Amount/transaction/day",
    "Transaction_amount",
    "Is declined",
    "Total Number of declines/day",
    "isForeignTransaction",
    "isHighRiskCountry",
    "Daily_chargeback_avg_amt",
    "6_month_avg_chbk_amt",
    "6-month_chbk_freq",
]

X = df[variables_clustering].to_numpy(dtype=float)


# ---------------------------------------------------------------
# 3. Algoritmo K-means implementado a mano (algoritmo de Lloyd)
#
#    Pasos:
#    1) Inicializar K centroides eligiendo K puntos al azar del dataset
#       (con una semilla fija para reproducibilidad).
#    2) Asignacion: cada punto se asigna al centroide mas cercano
#       (distancia euclidiana).
#    3) Actualizacion: cada centroide se recalcula como el promedio
#       de los puntos asignados a el.
#    4) Repetir 2-3 hasta que los centroides no cambien (convergencia)
#       o se alcance un numero maximo de iteraciones.
# ---------------------------------------------------------------
def kmeans_manual(X, k, semilla=42, max_iter=300, tolerancia=1e-6):
    rng = np.random.default_rng(semilla)

    # Paso 1: inicializacion - elegimos k puntos aleatorios como centroides
    indices_iniciales = rng.choice(len(X), size=k, replace=False)
    centroides = X[indices_iniciales].copy()

    for iteracion in range(max_iter):
        # Paso 2: asignacion
        # distancia euclidiana de cada punto a cada centroide:
        # d(x, c) = sqrt(sum((x_i - c_i)^2))
        distancias = np.zeros((len(X), k))
        for j in range(k):
            distancias[:, j] = np.sqrt(np.sum((X - centroides[j]) ** 2, axis=1))

        etiquetas = np.argmin(distancias, axis=1)

        # Paso 3: actualizacion - nuevo centroide = promedio de su grupo
        nuevos_centroides = np.zeros_like(centroides)
        for j in range(k):
            puntos_del_grupo = X[etiquetas == j]
            if len(puntos_del_grupo) > 0:
                nuevos_centroides[j] = puntos_del_grupo.mean(axis=0)
            else:
                # grupo vacio: se mantiene el centroide anterior
                nuevos_centroides[j] = centroides[j]

        # Paso 4: verificar convergencia
        desplazamiento = np.sqrt(np.sum((nuevos_centroides - centroides) ** 2))
        centroides = nuevos_centroides

        if desplazamiento < tolerancia:
            print(f"  Convergencia alcanzada en la iteracion {iteracion + 1}")
            break

    return centroides, etiquetas


def resumen_centroides(df_original, etiquetas, variables_clustering, k):
    """Arma una tabla legible de centroides + tamano de grupo + %fraude"""
    df_temp = df_original.copy()
    df_temp["grupo"] = etiquetas

    filas = []
    for grupo in range(k):
        subset = df_temp[df_temp["grupo"] == grupo]
        fila = {"grupo": grupo, "n_registros": len(subset)}
        for var in variables_clustering:
            fila[var] = subset[var].mean()
        fila["%_fraude_real"] = (subset["isFradulent"] == "Y").mean() * 100
        filas.append(fila)

    return pd.DataFrame(filas)


# ---------------------------------------------------------------
# 4. Ejecutar K-means manual con K=3
# ---------------------------------------------------------------
print("=" * 70)
print("K-MEANS MANUAL - K = 3")
print("=" * 70)
centroides_3, etiquetas_3 = kmeans_manual(X, k=3, semilla=42)
tabla_k3 = resumen_centroides(df, etiquetas_3, variables_clustering, k=3)
print(tabla_k3.round(2).to_string(index=False))
print()

# ---------------------------------------------------------------
# 5. Ejecutar K-means manual con K=2
# ---------------------------------------------------------------
print("=" * 70)
print("K-MEANS MANUAL - K = 2")
print("=" * 70)
centroides_2, etiquetas_2 = kmeans_manual(X, k=2, semilla=42)
tabla_k2 = resumen_centroides(df, etiquetas_2, variables_clustering, k=2)
print(tabla_k2.round(2).to_string(index=False))
print()

# ---------------------------------------------------------------
# 6. Verificacion cruzada contra sklearn.cluster.KMeans
# ---------------------------------------------------------------
from sklearn.cluster import KMeans

print("=" * 70)
print("VERIFICACION CRUZADA - sklearn.cluster.KMeans (K=3)")
print("=" * 70)
modelo_sklearn_3 = KMeans(n_clusters=3, random_state=42, n_init=10)
etiquetas_sklearn_3 = modelo_sklearn_3.fit_predict(X)
tabla_sklearn_3 = resumen_centroides(df, etiquetas_sklearn_3, variables_clustering, k=3)
print(tabla_sklearn_3.round(2).to_string(index=False))
print()

print("=" * 70)
print("VERIFICACION CRUZADA - sklearn.cluster.KMeans (K=2)")
print("=" * 70)
modelo_sklearn_2 = KMeans(n_clusters=2, random_state=42, n_init=10)
etiquetas_sklearn_2 = modelo_sklearn_2.fit_predict(X)
tabla_sklearn_2 = resumen_centroides(df, etiquetas_sklearn_2, variables_clustering, k=2)
print(tabla_sklearn_2.round(2).to_string(index=False))
print()

print(
    "Nota: los NUMEROS de grupo (0,1,2) pueden quedar en distinto orden "
    "entre la implementacion manual y sklearn (K-means no garantiza el "
    "mismo orden de etiquetas), pero los perfiles de los grupos -bajo, "
    "medio y alto riesgo- deben coincidir. Compara los centroides, no "
    "el numero de grupo."
)
print()

# ---------------------------------------------------------------
# 7. Metodo del codo (opcional, mencionado en la guia del profesor)
#    Inertia = suma de las distancias al cuadrado de cada punto a su
#    centroide asignado. A menor inertia, grupos mas compactos, pero
#    baja artificialmente al aumentar K, por eso se busca el "codo".
# ---------------------------------------------------------------
print("=" * 70)
print("METODO DEL CODO (K de 1 a 6)")
print("=" * 70)
inertias = []
for k in range(1, 7):
    modelo = KMeans(n_clusters=k, random_state=42, n_init=10)
    modelo.fit(X)
    inertias.append(modelo.inertia_)
    print(f"K={k}: inertia = {modelo.inertia_:,.2f}")
print()

# ---------------------------------------------------------------
# 8. Guardar resultados para el informe
# ---------------------------------------------------------------
tabla_k3.round(3).to_csv("outputs/punto2_kmeans_k3.csv", index=False)
tabla_k2.round(3).to_csv("outputs/punto2_kmeans_k2.csv", index=False)

pd.DataFrame({"K": range(1, 7), "inertia": inertias}).to_csv(
    "outputs/punto2_metodo_codo.csv", index=False
)

print("Resultados guardados en la carpeta 'outputs/'")